require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.GOOGLE_TRANSLATE_API_KEY;

app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/status", (_req, res) => {
  res.json({ configured: Boolean(API_KEY) });
});

app.post("/api/translate", async (req, res) => {
  const { text, target } = req.body || {};
  if (typeof text !== "string" || !text.trim()) {
    return res.status(400).json({ error: "Enter text to translate." });
  }
  if (text.length > 5000) {
    return res.status(413).json({ error: "Please keep each translation under 5,000 characters." });
  }
  if (!["hi", "mr"].includes(target)) {
    return res.status(400).json({ error: "Choose Hindi or Marathi." });
  }
  if (!API_KEY) {
    return res.status(503).json({
      error: "Online translation is not configured yet. Add GOOGLE_TRANSLATE_API_KEY to the server environment."
    });
  }

  try {
    const url = new URL("https://translation.googleapis.com/language/translate/v2");
    url.searchParams.set("key", API_KEY);
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ q: text, source: "en", target, format: "text" })
    });
    const data = await response.json();
    if (!response.ok) {
      const message = data?.error?.message || "Translation provider returned an error.";
      return res.status(response.status).json({ error: message });
    }
    const translatedText = data?.data?.translations?.[0]?.translatedText;
    if (typeof translatedText !== "string") {
      return res.status(502).json({ error: "The translation service returned an unexpected response." });
    }
    res.json({ translatedText });
  } catch (_err) {
    res.status(502).json({ error: "Could not reach the translation service. Check the server's internet connection." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`BhashaBridge running on port ${PORT}`));
