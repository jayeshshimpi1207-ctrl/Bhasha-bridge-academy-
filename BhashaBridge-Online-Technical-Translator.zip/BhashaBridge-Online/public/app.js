const $ = id => document.getElementById(id);
const BUILT_IN = [
["algorithm","कलन विधि","अल्गोरिदम"],["data structure","डेटा संरचना","डेटा स्ट्रक्चर"],
["semiconductor","अर्धचालक","अर्धवाहक"],["voltage","वोल्टता","विद्युतदाब"],
["electric current","विद्युत धारा","विद्युत प्रवाह"],["resistance","प्रतिरोध","प्रतिकार"],
["resistor","प्रतिरोधक","प्रतिरोधक"],["capacitor","संधारित्र","संधारित्र"],
["transistor","ट्रांजिस्टर","ट्रान्झिस्टर"],["microprocessor","सूक्ष्मप्रक्रमक","सूक्ष्मप्रक्रियक"],
["database","डेटाबेस","माहितीसंग्रह"],["operating system","प्रचालन तंत्र","कार्यप्रणाली"],
["programming language","प्रोग्रामिंग भाषा","प्रोग्रामिंग भाषा"],["source code","स्रोत कोड","स्रोत कोड"],
["compiler","संकलक","कंपायलर"],["variable","चर","चल"],["function","फलन","फलन"],
["array","सरणी","सरणी"],["pointer","सूचक","निर्देशक"],["machine learning","मशीन लर्निंग","मशीन लर्निंग"],
["artificial intelligence","कृत्रिम बुद्धिमत्ता","कृत्रिम बुद्धिमत्ता"],["neural network","तंत्रिका नेटवर्क","न्यूरल नेटवर्क"],
["encryption","कूटलेखन","कूटबद्धीकरण"],["bandwidth","बैंडविड्थ","बँडविड्थ"],
["frequency","आवृत्ति","वारंवारता"],["wavelength","तरंगदैर्ध्य","तरंगलांबी"],
["force","बल","बल"],["energy","ऊर्जा","ऊर्जा"],["power","शक्ति","शक्ती"],
["acceleration","त्वरण","प्रवेग"],["molecule","अणु","रेणू"],["atom","परमाणु","अणू"],
["derivative","अवकलज","अवकलज"],["integral","समाकल","समाकल"],["matrix","आव्यूह","आव्यूह"],
["vector","सदिश","सदिश"],["probability","प्रायिकता","संभाव्यता"],
["thermodynamics","ऊष्मागतिकी","ऊष्मागतिकी"],["stress","प्रतिबल","प्रतिबल"],
["strain","विकृति","विकृती"],["torque","बलाघूर्ण","आघूर्ण"],
["renewable energy","नवीकरणीय ऊर्जा","नवीकरणीय ऊर्जा"],["sensor","संवेदक","संवेदक"],
["robotics","रोबोटिकी","रोबोटिक्स"],["website","वेबसाइट","संकेतस्थळ"],
["debugging","त्रुटि-निवारण","दोषनिवारण"],["syntax","वाक्य-विन्यास","वाक्यरचना"]
].map(([en,hi,mr])=>({en,hi,mr}));
const STORE = "bhashabridge-online-custom-terms-v1";
let custom = [];
try { custom = JSON.parse(localStorage.getItem(STORE) || "[]"); if(!Array.isArray(custom)) custom=[]; } catch {}
const allTerms = () => [...BUILT_IN,...custom];
const norm = s => String(s||"").toLocaleLowerCase().trim().replace(/\s+/g," ");
function saveTerms(){try{localStorage.setItem(STORE,JSON.stringify(custom));}catch{}}
function applyGlossary(text,target){
  let out=text;
  const terms=allTerms().filter(t=>t[target]).sort((a,b)=>b.en.length-a.en.length);
  for(const t of terms){
    const escaped=t.en.replace(/[.*+?^${}()|[\]\\]/g,"\\$&").replace(/\s+/g,"\\s+");
    const re=new RegExp("(^|[^A-Za-z0-9_])("+escaped+")(?=$|[^A-Za-z0-9_])","gi");
    out=out.replace(re,(_m,prefix)=>prefix+t[target]);
  }
  return out;
}
async function checkStatus(){
 try{const r=await fetch("/api/status");const d=await r.json();
   $("status").textContent=d.configured?"Online translation ready":"API key not configured";
   $("status").className="status "+(d.configured?"ok":"bad");
 }catch{$("status").textContent="Server connection unavailable";$("status").className="status bad";}
}
$("translate").addEventListener("click",async()=>{
 const text=$("source").value.trim(),target=$("target").value;
 $("error").hidden=true;
 if(!text){$("error").textContent="Enter English text first.";$("error").hidden=false;return;}
 $("translate").disabled=true;$("translate").textContent="Translating…";$("result").textContent="";
 try{
   const response=await fetch("/api/translate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text,target})});
   const data=await response.json();
   if(!response.ok)throw new Error(data.error||"Translation failed.");
   $("result").textContent=applyGlossary(data.translatedText,target);
 }catch(e){$("error").textContent=e.message||"Could not translate. Check your connection and try again.";$("error").hidden=false;}
 finally{$("translate").disabled=false;$("translate").textContent="Translate online";}
});
$("copy").addEventListener("click",async()=>{
 try{await navigator.clipboard.writeText($("result").textContent);$("copy").textContent="Copied";setTimeout(()=>$("copy").textContent="Copy",1200);}
 catch{$("error").textContent="Clipboard access is unavailable in this browser. Select and copy the text manually.";$("error").hidden=false;}
});
$("addToggle").onclick=()=>{$("termForm").hidden=!$("termForm").hidden;};
$("termForm").addEventListener("submit",e=>{
 e.preventDefault();const en=$("enTerm").value.trim(),hi=$("hiTerm").value.trim(),mr=$("mrTerm").value.trim();
 if(!hi&&!mr){$("termMessage").textContent="Enter at least one translation.";return;}
 const idx=custom.findIndex(t=>norm(t.en)===norm(en));const item={en,hi,mr};
 if(idx>=0)custom[idx]=item;else custom.push(item);saveTerms();renderGlossary();e.target.reset();$("termMessage").textContent="Saved in this browser.";
});
$("termSearch").addEventListener("input",renderGlossary);
function renderGlossary(){
 const q=norm($("termSearch").value),items=allTerms().filter(t=>!q||norm(t.en).includes(q)||norm(t.hi).includes(q)||norm(t.mr).includes(q));
 const root=$("glossary");root.replaceChildren();
 if(!items.length){root.textContent="No matching terms.";return;}
 for(const t of items){const row=document.createElement("div");row.className="term";const title=document.createElement("strong");title.textContent=t.en;const meanings=document.createElement("small");meanings.textContent=`Hindi: ${t.hi||"—"} · Marathi: ${t.mr||"—"}`;row.append(title,meanings);root.append(row);}
}
renderGlossary();checkStatus();
