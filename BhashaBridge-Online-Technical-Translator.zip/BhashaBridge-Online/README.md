# BhashaBridge Online Technical Translator

This project translates English text into Hindi or Marathi through Google Cloud Translation and then applies a small preferred-technical-terms glossary. Users can add their own glossary terms in their browser.

## Important
- This is an online website project, not a public live URL yet.
- A Google Cloud project with Cloud Translation API enabled and a valid API key is required. Google Cloud may require billing; check your account's current pricing and quota.
- Keep the API key in the server environment only. Never paste it into `public/app.js` or `public/index.html`.
- Technical translation is context-sensitive. The glossary helps with selected terms; it does not guarantee every specialized term is correct.

## Run locally
1. Install Node.js 18 or newer.
2. In this project folder, run `npm install`.
3. Copy `.env.example` to `.env`.
4. Put your Google Cloud Translation API key in `.env` as `GOOGLE_TRANSLATE_API_KEY=...`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

## Deploy online
Deploy this folder to a host that supports Node.js (for example, a Node web service). Set `GOOGLE_TRANSLATE_API_KEY` as a secret/environment variable in the host dashboard and set the start command to `npm start`. The host will provide the public URL. Do not deploy only the `public` folder to a static host: the `/api/translate` server endpoint is required.

## Add custom technical terms
Use the “Add a term” form on the site. Custom terms are saved in that browser's local storage and applied after the online translation. They do not automatically sync between devices.
